/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 * All rights reserved.
 *
 * This source code is licensed under the license found in the
 * LICENSE file in the root directory of this source tree.
 */

using Meta.WitAi.TTS.Data;
using UnityEngine;

namespace Meta.WitAi.TTS.LipSync
{
    /// <summary>
    /// A class for adjusting mouth position during an audio animation based on the current viseme
    /// </summary>
    public class VisemeBlendShapeLipSync : BaseVisemeBlendShapeLipSync
    {
        /// <summary>
        /// The skinned mesh renderer for the face
        /// </summary>
        public SkinnedMeshRenderer meshRenderer;

        [SerializeField] private VisemeLipSyncAnimator _lipsyncAnimator;

        public override SkinnedMeshRenderer SkinnedMeshRenderer => meshRenderer;

        protected override void Awake()
        {
            if (!_lipsyncAnimator)
            {
                _lipsyncAnimator = GetComponent<VisemeLipSyncAnimator>();
            }
            base.Awake();
        }

        protected virtual void OnEnable()
        {
            _lipsyncAnimator.OnVisemeLerp.AddListener(OnVisemeLerp);
            _lipsyncAnimator.OnVisemeUpdate.AddListener(OnVisemeUpdate);
        }

        protected void OnDisable()
        {
            _lipsyncAnimator.OnVisemeLerp.RemoveListener(OnVisemeLerp);
            _lipsyncAnimator.OnVisemeUpdate.RemoveListener(OnVisemeUpdate);
        }
    }
}
